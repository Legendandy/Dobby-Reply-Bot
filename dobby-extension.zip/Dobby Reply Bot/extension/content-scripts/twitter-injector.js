// Twitter content script - main injector
class DobbyTwitter {
    constructor() {
        this.apiKey = null;
        this.observer = null;
        this.backend_url = 'https://dobby-backend-five.vercel.app';
        
        this.init();
    }

    async init() {
        // Load API key
        await this.loadApiKey();
        
        // Start observing Twitter DOM changes
        this.startObserving();
        
        // Initial scan for existing reply boxes
        this.scanForReplyBoxes();
        
        // Listen for API key updates
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.action === 'apiKeyUpdated') {
                this.apiKey = request.apiKey;
                this.scanForReplyBoxes(); // Re-scan to add buttons
            }
        });
    }

    async loadApiKey() {
        try {
            const result = await chrome.storage.sync.get(['dobbyApiKey']);
            this.apiKey = result.dobbyApiKey;
        } catch (error) {
            console.error('Error loading API key:', error);
        }
    }

    startObserving() {
        // Observe DOM changes to catch new reply boxes
        this.observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            this.checkForReplyBoxes(node);
                        }
                    });
                }
            });
        });

        this.observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    scanForReplyBoxes() {
        const replyBoxes = document.querySelectorAll('[data-testid="tweetTextarea_0"]');
        replyBoxes.forEach(box => this.addDobbyButton(box));
    }

    checkForReplyBoxes(element) {
        // Check if the element or its descendants contain reply boxes
        const replyBox = element.querySelector && element.querySelector('[data-testid="tweetTextarea_0"]');
        if (replyBox) {
            this.addDobbyButton(replyBox);
        }
        
        // Also check if the element itself is a reply box
        if (element.matches && element.matches('[data-testid="tweetTextarea_0"]')) {
            this.addDobbyButton(element);
        }
    }

    addDobbyButton(textarea) {
        // Skip if button already exists or no API key
        if (textarea.dobbyButtonAdded || !this.apiKey) {
            return;
        }

        // Mark as processed
        textarea.dobbyButtonAdded = true;

        // Find the tweet content we're replying to
        const tweetContent = this.extractTweetContent(textarea);
        if (!tweetContent) {
            return;
        }

        // Create Dobby button
        const dobbyButton = this.createDobbyButton(textarea, tweetContent);
        
        // Find the right place to insert the button
        const buttonContainer = this.findButtonContainer(textarea);
        if (buttonContainer) {
            buttonContainer.appendChild(dobbyButton);
        }
    }

    createDobbyButton(textarea, tweetContent) {
        const button = document.createElement('button');
        button.className = 'dobby-button';
        button.innerHTML = '🧙‍♂️ Dobby';
        button.title = 'Generate AI reply';
        
        button.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.handleDobbyClick(textarea, tweetContent, button);
        });

        return button;
    }

    findButtonContainer(textarea) {
        // Twitter's reply interface structure varies, need to find the toolbar
        let current = textarea.parentElement;
        let attempts = 0;
        
        while (current && attempts < 10) {
            // Look for the reply toolbar (contains tweet button, etc.)
            const toolbar = current.querySelector('[data-testid="toolBar"]') || 
                           current.querySelector('[role="group"]');
            
            if (toolbar) {
                return toolbar;
            }
            
            current = current.parentElement;
            attempts++;
        }

        // Fallback: create our own container
        const container = document.createElement('div');
        container.className = 'dobby-container';
        textarea.parentElement.appendChild(container);
        return container;
    }

    extractTweetContent(textarea) {
        // Navigate up to find the original tweet content
        let current = textarea;
        let attempts = 0;
        
        while (current && attempts < 15) {
            // Look for tweet text elements
            const tweetText = current.querySelector('[data-testid="tweetText"]') ||
                             current.querySelector('[lang]');
            
            if (tweetText && tweetText.textContent.trim()) {
                return tweetText.textContent.trim();
            }
            
            current = current.parentElement;
            attempts++;
        }

        // Alternative: look in the entire article/tweet container
        const tweetContainer = textarea.closest('[data-testid="tweet"]') ||
                              textarea.closest('article');
        
        if (tweetContainer) {
            const tweetText = tweetContainer.querySelector('[data-testid="tweetText"]');
            if (tweetText) {
                return tweetText.textContent.trim();
            }
        }

        return null;
    }

    async handleDobbyClick(textarea, tweetContent, button) {
        // Prevent multiple clicks
        if (button.disabled) return;
        
        button.disabled = true;
        button.innerHTML = '🔮 Thinking...';

        try {
            const reply = await this.generateReply(tweetContent);
            
            // Insert reply into textarea
            this.insertReply(textarea, reply);
            
            // Update button state
            button.innerHTML = '✨ Generated!';
            setTimeout(() => {
                button.innerHTML = '🧙‍♂️ Dobby';
                button.disabled = false;
            }, 2000);

            // Update stats
            chrome.runtime.sendMessage({ action: 'incrementStats' });

        } catch (error) {
            console.error('Error generating reply:', error);
            button.innerHTML = '❌ Error';
            setTimeout(() => {
                button.innerHTML = '🧙‍♂️ Dobby';
                button.disabled = false;
            }, 2000);
        }
    }

    async generateReply(tweetContent) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({
                action: 'generateReply',
                tweetContent: tweetContent,
                apiKey: this.apiKey
            }, (response) => {
                if (response.success) {
                    resolve(response.reply);
                } else {
                    reject(new Error(response.error));
                }
            });
        });
    }

    insertReply(textarea, reply) {
        // Clear existing content
        textarea.value = '';
        textarea.textContent = '';

        // Insert new reply
        textarea.focus();
        
        // Use execCommand for better compatibility
        document.execCommand('insertText', false, reply);
        
        // Trigger input events to notify Twitter
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
        textarea.dispatchEvent(new Event('change', { bubbles: true }));
        
        // Set cursor at end
        const range = document.createRange();
        const sel = window.getSelection();
        range.selectNodeContents(textarea);
        range.collapse(false);
        sel.removeAllRanges();
        sel.addRange(range);
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        new DobbyTwitter();
    });
} else {
    new DobbyTwitter();
}